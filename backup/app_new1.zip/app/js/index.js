const APP_NAME = "customer-portal";
const USER_REPORT_NAME = "All_Users";
const DOT_REPORT_NAME = "DOTs";
const ATTACT_REPORT_NAME = "Reptile_Attack_Vector_Result_Report";
// my s _ k _ p _y _ e id is live:.cid.612e4e8fa8e31ca7 , we can discuss here if it is possible

const dotTests = [
  /*{
    Attacks: [
      {
        Attack_Vector:{
          display_value: 'HOS',
          ID: "4184941000000259001",
          rec_val: true
        },
        Total: 56.2,
      },
      {
        Attack_Vector: {
          display_value: 'CSA',
          ID: "4184941000000259002"
        },
        Total: "42.8",
      }
    ],
    Name: 'DOT 1',
    ID: "4184941000000282115"
  },*/
  {
    Attacks: [
      {
        Attack_Vector: {
          display_value: 'Dq Files',
          ID: "4184941000000259003",
          rec_val: true
        },
        Total: "53.0"
      },
      {
        Attack_Vector: {
          display_value: 'Safety',
          ID: "4184941000000259004"
        },
        Total: "71.54"
      },
      {
        Attack_Vector: {
          display_value: 'Driver Onboarding',
          ID: "4184941000000259005"
        },
        DOT: {
          display_value: 'DOT 2',
          ID: "4184941000000282119",
          rec_val: true
        },
        Total: "66.2"
      }
    ],
    Name: 'DOT 2',
    ID: "4184941000000282119"
  },
  {
    Attacks: [
      {
        Attack_Vector: {
          display_value: 'Dq Files',
          ID: "4184941000000259003"
        },
        DOT: {
          display_value: 'DOT 3',
          ID: "4184941000000282123",
          rec_val: true
        },
        Total: "57.98"
      },  
      {
        Attack_Vector: {
          display_value: 'HOS',
          ID: "4184941000000259001",
          rec_val: true
        },
        DOT: {
          display_value: 'DOT 3',
          ID: "4184941000000282123"
        },
        Total: "49.76"
      },  
      {
        Attack_Vector: {
          display_value: 'Safety',
          ID: "4184941000000259004"
        },
        DOT: {
          display_value: 'DOT 3',
          ID: "4184941000000282123"
        },
        Total: "83.6"
      },
    ],
    Name: 'DOT 3',
    ID: "4184941000000282123"
  }
]

ZOHO.CREATOR.init().then(function(data){
  $('body').waitMe({
    effect : 'bounce',
    text : '',
    bg : "rgba(255,255,255,0.7)",
    color : "#000"
  });
  
  let queryParams = ZOHO.CREATOR.UTIL.getQueryParams();
  let config = {};
  if (Object.keys(queryParams).length > 0 ){
    config = {
      appName: APP_NAME,
      reportName: USER_REPORT_NAME,
      page: 1,
      pageSize: 1,
      criteria: '(Email == "' + queryParams["loginUserEmail"] + '")',
    }
  }

  retrieveInfo(config );
});

async function retrieveInfo(config ){
  const company_id = await getCompanyId(config );
  if (company_id == "" ){
    alert("CompanyId don't exist");
    $('body').waitMe("hide");
    return;
  }

  let dot_info = await getAllDots(company_id);
  for (var i = 0; i < dot_info.length; i++ ){
    if (i > 1 ) break;
    const attack_info = await getAttackItem(dot_info[i]["ID"]);
    let att_info_data = [];
    //for(const item in attack_infos){
    //  att_info_data.push(attack_infos[item]);
    //}
    dot_info[i]["Attacks"] = attack_info;
  }
  console.log(dot_info, dotTests);
  //dot_info = dotTests;
  graph_data = handleDots(dot_info );
  console.log(graph_data)
  drawGraph(graph_data );
  $('body').waitMe("hide");
}

async function getCompanyId(config ){
  let response = await ZOHO.CREATOR.API.getAllRecords(config);
  let companyID = "";
  if (response.data.length > 0 ){ 
    companyID = response.data[0]["Company"]["ID"];
  }
  return companyID;
}

async function getAllDots(companyID ){
  const dotsConfig = {
    appName: APP_NAME,
    reportName: DOT_REPORT_NAME,
    page: 1,
    pageSize: 10,
    criteria: "(Company == " + companyID + ")",
  };

  let response = await ZOHO.CREATOR.API.getAllRecords(dotsConfig);
  let dotInfo = {};
  if (response.data.length > 0) {
    dotInfo = response.data;
  }
  return dotInfo;
}

/*async function getAttackVector(dots ){
  let attacks = [];
  for (var i = 0; i < dots.length; i++ ){
    if (i > 0 ) continue;
    var dot = dots[i];
    const config = {
      appName: APP_NAME,
      reportName: ATTACT_REPORT_NAME,
      page: 1,
      pageSize: 10,
      criteria: "(DOT == " + dot + ")",
    }
    let item = await getAttackItem(config ); 
    attacks = [... item ];
  }
  return attacks;
}*/

async function getAttackItem(dot_id ){
  const config = {
    appName: APP_NAME,
    reportName: ATTACT_REPORT_NAME,
    page: 1,
    pageSize: 10,
    criteria: "(DOT == " + dot_id + ")",
  }
  let response = await ZOHO.CREATOR.API.getAllRecords(config);
  var attackVectors = response.data;

  let attvArray = [];
  for (var i = 0; i < attackVectors.length; i++ ){
    var item = attackVectors[i];
    var attackVectorNew = _.pick(item, 'Attack_Vector', 'DOT', 'Total')
    attvArray.push(attackVectorNew);
  }

  return attvArray;
}
