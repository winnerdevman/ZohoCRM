function handleDots(dot_info){
    let attack_ids = [];
    let attack_infos = [];
    for (let i = 0; i < dot_info.length; i++){
        var item = dot_info[i];
        var dot_max = 0;
        for (let j = 0; j < item["Attacks"].length; j++ ){
            var attack_item = item["Attacks"][j];
            var att_vect = attack_item["Attack_Vector"];
            if (attack_item["Total"] > dot_max ){
                dot_max = parseFloat(attack_item["Total"]);
            }
            if (attack_ids.indexOf(att_vect["ID"]) == -1){
                attack_ids.push(att_vect["ID"]);
                attack_infos[att_vect["ID"]] = attack_item;
            }
            
            if (attack_infos[att_vect["ID"]]["Total"] < attack_item["Total"]){
                attack_infos[att_vect["ID"]]["Total"] = parseFloat(attack_item["Total"]);
            }
        }
        dot_info[i]["Total"] = dot_max;
    }
    let at_arr = [];
    for(const item in attack_infos){
        at_arr.push(attack_infos[item]);
    }
    dot_info.sort(function(a, b){return a.Total - b.Total});
    at_arr.sort(function(a,b){return b.Total - a.Total})
    return {dot_info: [...dot_info], attack_info: [...at_arr]};
}